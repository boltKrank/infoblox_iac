#!/bin/bash
echo "Grid Master initialization..."
# You can add WAPI calls here to configure the master automatically
