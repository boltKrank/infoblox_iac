#!/bin/bash
echo "Grid Member initialization..."
# Grid join will be handled via Ansible
